﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nars_cp3
{
    public partial class technical_home_page : Form
    {
        public technical_home_page()
        {
            InitializeComponent();
        }

        private void technical_home_page_Load(object sender, EventArgs e)
        {

        }
    }
}
