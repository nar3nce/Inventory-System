﻿namespace Nars_cp3
{
    partial class form_add_borrow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.borrow_form_id = new System.Windows.Forms.Label();
            this.asset_label1 = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.txtb_avtivity = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.borrow_date = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.txtb_purpose = new System.Windows.Forms.TextBox();
            this.username_label = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dept_label = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtb_date = new Guna.UI.WinForms.GunaDateTimePicker();
            this.Edit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.panel13.SuspendLayout();
            this.SuspendLayout();
            // 
            // borrow_form_id
            // 
            this.borrow_form_id.AutoSize = true;
            this.borrow_form_id.Font = new System.Drawing.Font("Arial", 9F);
            this.borrow_form_id.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.borrow_form_id.Location = new System.Drawing.Point(135, 11);
            this.borrow_form_id.Name = "borrow_form_id";
            this.borrow_form_id.Size = new System.Drawing.Size(59, 15);
            this.borrow_form_id.TabIndex = 118;
            this.borrow_form_id.Text = "Technical";
            // 
            // asset_label1
            // 
            this.asset_label1.AutoSize = true;
            this.asset_label1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.asset_label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.asset_label1.Location = new System.Drawing.Point(6, 9);
            this.asset_label1.Name = "asset_label1";
            this.asset_label1.Size = new System.Drawing.Size(135, 16);
            this.asset_label1.TabIndex = 117;
            this.asset_label1.Text = "Borrowing Form # :";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // txtb_avtivity
            // 
            this.txtb_avtivity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.txtb_avtivity.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_avtivity.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_avtivity.ForeColor = System.Drawing.Color.Cornsilk;
            this.txtb_avtivity.Location = new System.Drawing.Point(177, 219);
            this.txtb_avtivity.Multiline = true;
            this.txtb_avtivity.Name = "txtb_avtivity";
            this.txtb_avtivity.Size = new System.Drawing.Size(96, 22);
            this.txtb_avtivity.TabIndex = 116;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.FloralWhite;
            this.label6.Location = new System.Drawing.Point(82, 222);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 13);
            this.label6.TabIndex = 114;
            this.label6.Text = "Name of Activity :";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.White;
            this.panel11.Location = new System.Drawing.Point(58, 249);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(200, 1);
            this.panel11.TabIndex = 113;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FloralWhite;
            this.label2.Location = new System.Drawing.Point(82, 268);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 110;
            this.label2.Text = "Date of Activity :";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.White;
            this.panel4.Location = new System.Drawing.Point(57, 335);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(200, 1);
            this.panel4.TabIndex = 107;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FloralWhite;
            this.label5.Location = new System.Drawing.Point(82, 310);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 13);
            this.label5.TabIndex = 106;
            this.label5.Text = "Purpose of Activity :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(55, 292);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 1);
            this.panel2.TabIndex = 102;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.RoyalBlue;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(173, 355);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(86, 33);
            this.button4.TabIndex = 95;
            this.button4.Text = "Clear";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.RoyalBlue;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(53, 355);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 33);
            this.button1.TabIndex = 94;
            this.button1.Text = "Add";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel6
            // 
            this.panel6.BackgroundImage = global::Nars_cp3.Properties.Resources.desc;
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel6.Location = new System.Drawing.Point(46, 214);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(30, 30);
            this.panel6.TabIndex = 115;
            // 
            // panel13
            // 
            this.panel13.BackgroundImage = global::Nars_cp3.Properties.Resources.c3;
            this.panel13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel13.Controls.Add(this.panel14);
            this.panel13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel13.Location = new System.Drawing.Point(294, 7);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(18, 18);
            this.panel13.TabIndex = 119;
            this.panel13.Click += new System.EventHandler(this.panel13_Click);
            // 
            // panel14
            // 
            this.panel14.BackgroundImage = global::Nars_cp3.Properties.Resources.user_icn;
            this.panel14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel14.Location = new System.Drawing.Point(236, -34);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(21, 23);
            this.panel14.TabIndex = 42;
            // 
            // panel5
            // 
            this.panel5.BackgroundImage = global::Nars_cp3.Properties.Resources.status;
            this.panel5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel5.Location = new System.Drawing.Point(46, 260);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(30, 30);
            this.panel5.TabIndex = 111;
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = global::Nars_cp3.Properties.Resources.avail2;
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Location = new System.Drawing.Point(46, 302);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(30, 30);
            this.panel3.TabIndex = 108;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label7.Location = new System.Drawing.Point(6, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 16);
            this.label7.TabIndex = 120;
            this.label7.Text = "Date :";
            // 
            // borrow_date
            // 
            this.borrow_date.AutoSize = true;
            this.borrow_date.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.borrow_date.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.borrow_date.Location = new System.Drawing.Point(53, 31);
            this.borrow_date.Name = "borrow_date";
            this.borrow_date.Size = new System.Drawing.Size(59, 15);
            this.borrow_date.TabIndex = 121;
            this.borrow_date.Text = "Technical";
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::Nars_cp3.Properties.Resources.home_ic_light;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(46, 169);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(30, 30);
            this.panel1.TabIndex = 119;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FloralWhite;
            this.label1.Location = new System.Drawing.Point(82, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 118;
            this.label1.Text = "Department :";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Location = new System.Drawing.Point(58, 204);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(200, 1);
            this.panel7.TabIndex = 117;
            // 
            // txtb_purpose
            // 
            this.txtb_purpose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.txtb_purpose.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtb_purpose.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtb_purpose.ForeColor = System.Drawing.Color.Cornsilk;
            this.txtb_purpose.Location = new System.Drawing.Point(187, 307);
            this.txtb_purpose.Multiline = true;
            this.txtb_purpose.Name = "txtb_purpose";
            this.txtb_purpose.Size = new System.Drawing.Size(95, 22);
            this.txtb_purpose.TabIndex = 125;
            // 
            // username_label
            // 
            this.username_label.AutoSize = true;
            this.username_label.Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.username_label.Location = new System.Drawing.Point(176, 114);
            this.username_label.Name = "username_label";
            this.username_label.Size = new System.Drawing.Size(69, 17);
            this.username_label.TabIndex = 127;
            this.username_label.Text = "Technical";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.label4.Location = new System.Drawing.Point(55, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 18);
            this.label4.TabIndex = 126;
            this.label4.Text = "Requested By :";
            // 
            // dept_label
            // 
            this.dept_label.AutoSize = true;
            this.dept_label.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dept_label.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.dept_label.Location = new System.Drawing.Point(154, 176);
            this.dept_label.Name = "dept_label";
            this.dept_label.Size = new System.Drawing.Size(59, 15);
            this.dept_label.TabIndex = 128;
            this.dept_label.Text = "Technical";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Location = new System.Drawing.Point(54, 136);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(200, 1);
            this.panel8.TabIndex = 118;
            // 
            // txtb_date
            // 
            this.txtb_date.BaseColor = System.Drawing.Color.White;
            this.txtb_date.BorderColor = System.Drawing.Color.Silver;
            this.txtb_date.CustomFormat = null;
            this.txtb_date.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.txtb_date.FocusedColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtb_date.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtb_date.ForeColor = System.Drawing.Color.Black;
            this.txtb_date.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtb_date.Location = new System.Drawing.Point(173, 257);
            this.txtb_date.MaxDate = new System.DateTime(9998, 12, 31, 0, 0, 0, 0);
            this.txtb_date.MinDate = new System.DateTime(1753, 1, 1, 0, 0, 0, 0);
            this.txtb_date.Name = "txtb_date";
            this.txtb_date.OnHoverBaseColor = System.Drawing.Color.White;
            this.txtb_date.OnHoverBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtb_date.OnHoverForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(88)))), ((int)(((byte)(255)))));
            this.txtb_date.OnPressedColor = System.Drawing.Color.Black;
            this.txtb_date.Size = new System.Drawing.Size(109, 30);
            this.txtb_date.TabIndex = 124;
            this.txtb_date.Text = "2/11/2020";
            this.txtb_date.Value = new System.DateTime(2020, 2, 11, 18, 2, 52, 837);
            this.txtb_date.ValueChanged += new System.EventHandler(this.txtb_date_ValueChanged);
            // 
            // Edit
            // 
            this.Edit.BackColor = System.Drawing.Color.RoyalBlue;
            this.Edit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Edit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Edit.Location = new System.Drawing.Point(53, 355);
            this.Edit.Name = "Edit";
            this.Edit.Size = new System.Drawing.Size(86, 33);
            this.Edit.TabIndex = 129;
            this.Edit.Text = "Edit";
            this.Edit.UseVisualStyleBackColor = false;
            this.Edit.Click += new System.EventHandler(this.Edit_Click);
            // 
            // form_add_borrow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(3)))), ((int)(((byte)(3)))));
            this.ClientSize = new System.Drawing.Size(319, 421);
            this.Controls.Add(this.Edit);
            this.Controls.Add(this.panel8);
            this.Controls.Add(this.dept_label);
            this.Controls.Add(this.username_label);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtb_purpose);
            this.Controls.Add(this.txtb_date);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel7);
            this.Controls.Add(this.borrow_date);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.borrow_form_id);
            this.Controls.Add(this.asset_label1);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel13);
            this.Controls.Add(this.txtb_avtivity);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel11);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "form_add_borrow";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_add_borrow";
            this.Load += new System.EventHandler(this.form_add_borrow_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.panel13.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label borrow_form_id;
        private System.Windows.Forms.Label asset_label1;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txtb_avtivity;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label borrow_date;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtb_purpose;
        private System.Windows.Forms.Label username_label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label dept_label;
        private System.Windows.Forms.Panel panel8;
        private Guna.UI.WinForms.GunaDateTimePicker txtb_date;
        private System.Windows.Forms.Button Edit;
    }
}